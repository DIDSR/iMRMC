# Create an MRMC data frame (Gallas2014_J-Med-Img_v1p031006)
simRoeMetz.config <- sim.gRoeMetz.config()

# Simulate data
df.MRMC <- sim.gRoeMetz(simRoeMetz.config)

# Split the data
df.MRMC.pos <- droplevels(df.MRMC[grepl("pos", df.MRMC$caseID), ])

# Calculate the reader- and case-averaged difference in scores from modalityA and modality B
# (kernelFlag = 2 specifies the U-statistics kernel to be the difference in scores)
result <- uStat11.jointD(
  df.MRMC.pos,
  kernelFlag = 2,
  keyColumns = c("readerID", "caseID", "modalityID", "score"),
  modalitiesToCompare = c("modalityA", "modalityB", "modalityB", "modalityA"))

print("X=meanScoreA-meanScoreB, Y=meanScoreB-meanScoreA, X-Y")
print(result$mean)
print("var(X), var(Y), var(X-Y)")
print(result$var)
