library(testthat)

testthat::test_check("iMRMC")
