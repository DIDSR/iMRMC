library(testthat)

testthat::test_check("mrmcAgreement")
